<?php
namespace app\common\model;

use think\Model;

class Nav extends Model
{

}