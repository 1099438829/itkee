ITKEE后台管理系统
===============

ITKEE系统在保持thinkphp5快速开发和大道至简的核心理念不变的同时，最大可能的保留了thinkphp5的开发规范，减少用户开发学习成本

> ITKEE后台管理系统 的运行环境要求PHP5.4以上。

详细开发文档参考 (http://www.itkee.cn/doc.html)

官网地址:http://www.itkee.cn/doc.html

社区交流:http://www.itkee.cn/topic.html

